#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <string>
using namespace std;

map<char, vector<string>> grammar;
map<char, set<char>> firstSets;
map<char, set<char>> followSets;
set<char> nonTerminals = {'S', 'A', 'B', 'C', 'D'};

bool isNonTerminal(char c) 
{
    return nonTerminals.find(c) != nonTerminals.end();
}

set<char> findFirst(string str) 
{
    set<char> result;
    
    for(int i=0;i<str.length();i++) 
    {
        char c = str[i];
        
        if(!isNonTerminal(c))
        {
            result.insert(c);
            return result;
        }
        
        set<char> firstOfC = firstSets[c];
        for(char ch : firstOfC)
        {
            if (ch != 'e')
            {
                result.insert(ch);
            }
        }
        
        if(firstOfC.find('e') == firstOfC.end())
        {
            return result;
        }
        
        if(i == str.length() - 1)
        {
            result.insert('e');
        }
    }
    
    return result;
}

void computeFirst()
{
    bool changed = true;
    
    while(changed)
    {
        changed = false;
        
        for(char nt : nonTerminals)
        {
            int oldSize = firstSets[nt].size();
            
            for(string prod : grammar[nt])
            {
                set<char> firstOfProd = findFirst(prod);
                for(char c : firstOfProd) 
                {
                    firstSets[nt].insert(c);
                }
            }
            
            if(firstSets[nt].size() > oldSize) 
            {
                changed = true;
            }
        }
    }
}

void computeFollow() 
{
    followSets['S'].insert('$');
    
    bool changed = true;
    
    while(changed) 
    {
        changed = false;
        
        for(char nt : nonTerminals) 
        {
            for(string prod : grammar[nt]) 
            {
                for(int i = 0; i < prod.length(); i++) 
                {
                    if(isNonTerminal(prod[i])) 
                    {
                        int oldSize = followSets[prod[i]].size();
                        
                        if(i + 1 < prod.length()) 
                        {
                            string beta = prod.substr(i + 1);
                            set<char> firstBeta = findFirst(beta);
                            
                            for(char c : firstBeta) 
                            {
                                if(c != 'e') 
                                {
                                    followSets[prod[i]].insert(c);
                                }
                            }
                            
                            if(firstBeta.find('e') != firstBeta.end()) 
                            {
                                for(char c : followSets[nt]) 
                                {
                                    followSets[prod[i]].insert(c);
                                }
                            }
                        } 
                        else 
                        {
                            for(char c : followSets[nt]) 
                            {
                                followSets[prod[i]].insert(c);
                            }
                        }
                        
                        if(followSets[prod[i]].size() > oldSize) 
                        {
                            changed = true;
                        }
                    }
                }
            }
        }
    }
}

void printSet(char symbol, map<char, set<char>>& sets, string type) 
{
    cout << type << "(" << symbol << ") = {";
    bool first = true;
    for(char c : sets[symbol]) 
    {
        if(!first) cout << ", ";
        cout << c;
        first = false;
    }
    cout << "}" << endl;
}

int main() {
    grammar['S'].push_back("ABC");
    grammar['S'].push_back("D");
    grammar['A'].push_back("a");
    grammar['A'].push_back("e");
    grammar['B'].push_back("b");
    grammar['B'].push_back("e");
    grammar['C'].push_back("(S)");
    grammar['C'].push_back("c");
    grammar['D'].push_back("AC");
    
    computeFirst();
    computeFollow();
    
    for(char nt : nonTerminals)
    {
        printSet(nt, firstSets, "First");
    }
    
    cout << endl;
    
    for(char nt : nonTerminals)
    {
        printSet(nt, followSets, "Follow");
    }
    
    return 0;
}