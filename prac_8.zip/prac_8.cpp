#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <stack>
using namespace std;

map<char, vector<string>> grammar;
map<char, set<char>> firstSets;
map<char, set<char>> followSets;
map<char, map<char, string>> parsingTable;
set<char> nonTerminals = {'S','A','B','C','D'};
set<char> terminals = {'a','b','c','(',')','$'};
char newNonTerminal = 'X';

bool isNonTerminal(char c)
{
    return nonTerminals.find(c) != nonTerminals.end();
}

set<char> findFirst(string str)
{
    set<char> result;

    for(int i=0;i<str.length();i++)
    {
        char c=str[i];

        if(!isNonTerminal(c))
        {
            result.insert(c);
            return result;
        }

        set<char> temp=firstSets[c];

        for(char ch:temp)
        {
            if(ch!='e')
            {
                result.insert(ch);
            }
        }

        if(temp.find('e')==temp.end())
        {
            return result;
        }

        if(i==str.length()-1)
        {
            result.insert('e');
        }
    }

    return result;
}

void computeFirst()
{
    bool changed=true;

    while(changed)
    {
        changed=false;

        for(char nt:nonTerminals)
        {
            int oldSize=firstSets[nt].size();

            for(string prod:grammar[nt])
            {
                set<char> temp=findFirst(prod);
                for(char c:temp)
                {
                    firstSets[nt].insert(c);
                }
            }

            if(firstSets[nt].size()>oldSize)
            {
                changed=true;
            }
        }
    }
}

void computeFollow()
{
    followSets['S'].insert('$');
    bool changed=true;

    while(changed)
    {
        changed=false;

        for(char nt:nonTerminals)
        {
            for(string prod:grammar[nt])
            {
                for(int i=0;i<prod.length();i++)
                {
                    if(isNonTerminal(prod[i]))
                    {
                        int oldSize=followSets[prod[i]].size();

                        if(i+1<prod.length())
                        {
                            string beta=prod.substr(i+1);
                            set<char> firstBeta=findFirst(beta);

                            for(char c:firstBeta)
                            {
                                if(c!='e')
                                {
                                    followSets[prod[i]].insert(c);
                                }
                            }

                            if(firstBeta.find('e')!=firstBeta.end())
                            {
                                for(char c:followSets[nt])
                                {
                                    followSets[prod[i]].insert(c);
                                }
                            }
                        }
                        else
                        {
                            for(char c:followSets[nt])
                            {
                                followSets[prod[i]].insert(c);
                            }
                        }

                        if(followSets[prod[i]].size()>oldSize)
                        {
                            changed=true;
                        }
                    }
                }
            }
        }
    }
}

bool constructParsingTable()
{
    parsingTable.clear();
    bool isLL1=true;

    for(char nt:nonTerminals)
    {
        for(string prod:grammar[nt])
        {
            set<char> firstAlpha=findFirst(prod);

            for(char t:firstAlpha)
            {
                if(t!='e')
                {
                    if(parsingTable[nt][t]!="")
                    {
                        isLL1=false;
                    }
                    parsingTable[nt][t]=prod;
                }
            }

            if(firstAlpha.find('e')!=firstAlpha.end())
            {
                for(char t:followSets[nt])
                {
                    if(parsingTable[nt][t]!="")
                    {
                        isLL1=false;
                    }
                    parsingTable[nt][t]=prod;
                }
            }
        }
    }

    return isLL1;
}

void printParsingTable()
{
    cout<<"\nPredictive Parsing Table:\n\n";
    cout<<"     ";
    for(char t:terminals)
    {
        cout<<t<<"     ";
    }
    cout<<endl;

    for(char nt:nonTerminals)
    {
        cout<<nt<<"  ";
        for(char t:terminals)
        {
            if(parsingTable[nt][t]!="")
            {
                cout<<nt<<"->"<<parsingTable[nt][t]<<"  ";
            }
            else
            {
                cout<<"-     ";
            }
        }
        cout<<endl;
    }
}

void leftFactor()
{
    bool changed=true;

    while(changed)
    {
        changed=false;

        for(char nt:nonTerminals)
        {
            vector<string> prods=grammar[nt];

            for(int i=0;i<prods.size();i++)
            {
                for(int j=i+1;j<prods.size();j++)
                {
                    if(prods[i][0]==prods[j][0] && prods[i][0]!='e')
                    {
                        char newNT=newNonTerminal++;
                        nonTerminals.insert(newNT);

                        string prefix="";
                        prefix+=prods[i][0];

                        grammar[nt].clear();
                        grammar[nt].push_back(prefix+newNT);

                        string alpha=prods[i].substr(1);
                        string beta=prods[j].substr(1);

                        if(alpha=="") alpha="e";
                        if(beta=="") beta="e";

                        grammar[newNT].push_back(alpha);
                        grammar[newNT].push_back(beta);

                        changed=true;
                        break;
                    }
                }
                if(changed) break;
            }
            if(changed) break;
        }
    }
}

bool validateString(string input)
{
    stack<char> st;
    st.push('$');
    st.push('S');
    input+='$';
    int i=0;

    while(!st.empty())
    {
        char top=st.top();
        char current=input[i];

        if(top==current)
        {
            st.pop();
            i++;
        }
        else if(!isNonTerminal(top))
        {
            return false;
        }
        else
        {
            if(parsingTable[top][current]=="")
            {
                return false;
            }

            st.pop();
            string prod=parsingTable[top][current];

            if(prod!="e")
            {
                for(int j=prod.length()-1;j>=0;j--)
                {
                    st.push(prod[j]);
                }
            }
        }
    }

    return true;
}

int main()
{
    grammar['S'].push_back("ABC");
    grammar['S'].push_back("D");
    grammar['A'].push_back("a");
    grammar['A'].push_back("e");
    grammar['B'].push_back("b");
    grammar['B'].push_back("e");
    grammar['C'].push_back("(S)");
    grammar['C'].push_back("c");
    grammar['D'].push_back("AC");

    computeFirst();
    computeFollow();

    bool isLL1=constructParsingTable();

    if(!isLL1)
    {
        leftFactor();
        firstSets.clear();
        followSets.clear();
        computeFirst();
        computeFollow();
        isLL1=constructParsingTable();
    }

    printParsingTable();

    if(isLL1)
    {
        cout<<"\nGrammar is LL(1)\n";
    }
    else
    {
        cout<<"\nGrammar is NOT LL(1)\n";
    }

        int choice;
    string input;

    while(true)
    {
        cout<<"\n1. Enter string\n";
        cout<<"2. Exit\n";
        cout<<"Enter choice: ";
        cin>>choice;

        switch(choice)
        {
            case 1:
                cout<<"Enter string: ";
                cin>>input;

                if(validateString(input))
                {
                    cout<<"Valid string\n";
                }
                else
                {
                    cout<<"Invalid string\n";
                }
                break;

            case 2:
                return 0;

            default:
                cout<<"Invalid choice\n";
        }
    }

    return 0;
}